#include "String.h"

int String::my_strlen(const char* s) {
    int len = 0;
    while (s[len] != '\0') len++;
    return len;
}

void String::my_strcpy(char* dest, const char* src) {
    int i = 0;
    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
}

String::String(int len) {
    length = len;
    str = new char[length + 1];
    str[0] = '\0';
}

String::String(const char* s) {
    length = my_strlen(s);
    str = new char[length + 1];
    my_strcpy(str, s);
}

String::String(const String& other) {
    length = other.length;
    str = new char[length + 1];
    my_strcpy(str, other.str);
}

String::~String() {
    delete[] str;
}

void String::print() const {
    cout << str << endl;
}

void String::clear() {
    delete[] str;
    length = 0;
    str = new char[1];
    str[0] = '\0';
}

String String::operator+(const String& other) {
    int newLen = length + other.length;
    char* temp = new char[newLen + 1];

    int i = 0;

    for (; i < length; i++) {
        temp[i] = str[i];
    }

    for (int j = 0; j < other.length; j++) {
        temp[i++] = other.str[j];
    }

    temp[i] = '\0';

    String result(temp);
    delete[] temp;
    return result;
}

String String::operator-(const String& other) {
    char* temp = new char[length + 1];
    int k = 0;

    for (int i = 0; i < length; i++) {
        bool found = false;

        for (int j = 0; j < other.length; j++) {
            if (str[i] == other.str[j]) {
                found = true;
                break;
            }
        }

        if (!found) {
            temp[k++] = str[i];
        }
    }

    temp[k] = '\0';

    String result(temp);
    delete[] temp;
    return result;
}

bool String::operator<(const String& other) {
    return length < other.length;
}

bool String::operator>(const String& other) {
    return length > other.length;
}